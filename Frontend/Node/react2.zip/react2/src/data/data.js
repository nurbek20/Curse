export const data = [
    {
        img: 'https://media-exp1.licdn.com/dms/image/C560BAQHMnA03XDdf3w/company-logo_200_200/0/1519855918965?e=2147483647&v=beta&t=J3kUMZwIphc90TFKH5oOO9Sa9K59fimgJf-s_okU3zs',
        title: "title 1",
        description:'title discription',
        price:500,
        count:1,
        discount:7,
        id:1
    },
    {
        img: 'https://media-exp1.licdn.com/dms/image/C560BAQHMnA03XDdf3w/company-logo_200_200/0/1519855918965?e=2147483647&v=beta&t=J3kUMZwIphc90TFKH5oOO9Sa9K59fimgJf-s_okU3zs',
        title: "title 2",
        description:'title discription',
        price:450,
        count:1,
        discount:8,
        id:2
    },
    {
        img: 'https://media-exp1.licdn.com/dms/image/C560BAQHMnA03XDdf3w/company-logo_200_200/0/1519855918965?e=2147483647&v=beta&t=J3kUMZwIphc90TFKH5oOO9Sa9K59fimgJf-s_okU3zs',
        title: "title 3",
        description:'title discription',
        price:400,
        count:1,
        discount:null,
        id:3
    },
    {
        img: 'https://media-exp1.licdn.com/dms/image/C560BAQHMnA03XDdf3w/company-logo_200_200/0/1519855918965?e=2147483647&v=beta&t=J3kUMZwIphc90TFKH5oOO9Sa9K59fimgJf-s_okU3zs',
        title: "title 4",
        description:'title discription',
        price:100,
        count:1,
        discount:4,
        id:4
    },
    {
        img: 'https://media-exp1.licdn.com/dms/image/C560BAQHMnA03XDdf3w/company-logo_200_200/0/1519855918965?e=2147483647&v=beta&t=J3kUMZwIphc90TFKH5oOO9Sa9K59fimgJf-s_okU3zs',
        title: "title 5",
        description:'title discription',
        price:900,
        count:1,
        discount:20,
        id:5
    },
    {
        img: 'https://media-exp1.licdn.com/dms/image/C560BAQHMnA03XDdf3w/company-logo_200_200/0/1519855918965?e=2147483647&v=beta&t=J3kUMZwIphc90TFKH5oOO9Sa9K59fimgJf-s_okU3zs',
        title: "title 6",
        description:'title discription',
        price:400,
        count:1,
        discount:6,
        id:6
    },
    {
        img: 'https://media-exp1.licdn.com/dms/image/C560BAQHMnA03XDdf3w/company-logo_200_200/0/1519855918965?e=2147483647&v=beta&t=J3kUMZwIphc90TFKH5oOO9Sa9K59fimgJf-s_okU3zs',
        title: "title 7",
        description:'title discription',
        price:400,
        count:1,
        discount:5,
        id:7
    },
    {
        img: 'https://media-exp1.licdn.com/dms/image/C560BAQHMnA03XDdf3w/company-logo_200_200/0/1519855918965?e=2147483647&v=beta&t=J3kUMZwIphc90TFKH5oOO9Sa9K59fimgJf-s_okU3zs',
        title: "title 8",
        description:'title discription',
        price:700,
        count:1,
        discount:4,
        id:8
    }
]