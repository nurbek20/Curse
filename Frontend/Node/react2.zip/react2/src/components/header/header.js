import { Link } from "react-router-dom"
// import Header from "./header";


const Header = ({length}) => {
    return(
        <div className="header">
            <div><Link to='/'>Home</Link></div>
            <div><Link to='/cart'>Basket {length}</Link></div>
        </div>
    )
}

export default Header;