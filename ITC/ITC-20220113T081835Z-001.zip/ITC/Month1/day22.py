# """Условия if-elif-alse"""
# a=int(input("Сколько вам лет?"))    # int
# # b=input("Сколько вам лет?")         # str
# # print(type(a))
# # print(type(b))
# if a>18 or a == 18:               # 20>18=>True
#     print('доступ разрешен!')
#     print('доступ разрешен!')
# elif a<18  and a>8:    
#     print('доступ не разрешен!')
# else:
#     print('Доступа нет')    

# """List -спсиок , массив"""
# lst=list()
# print(type(lst))

# lst2=list([12,58,True,"Text",15.2,["good",45]])
# print(lst2)
# print(len(lst2))
# print(lst2[2])
# print(lst2[4])
# print(lst2[3])
# print(lst2[5][0])
# lst3=[]
# lst4=[45,87,8]
# print(lst3)
# lst3.append(54)
# lst3.append(False)
# print(lst3)
# lst4[0]="Python"
# lst4[2]=False
# print(lst4)
# new_lst=lst4.copy()
# new_lst[-1]=False
# print(new_lst)
# print(lst4[0:2])
# l=[15,47,69,478,1]
# print(l[0:3])
# """dictionary-словарь"""
# b=5,
# print(type(b))
