# fist_number=5             #int
# second_namber=3.5         #float
# spring="ITCBootcamp"      #str
# spring1='ITCBootcamp Osh' #str
# text="it's book"
# text1='it\s book'
# print(text)
# blood=True or False       #bool
# s = float(input())
# s = int(input())
# s = str(input())

# s = input(float()) #ERROR