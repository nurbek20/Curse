# input (запрос)
a = int(input('enter random number:'))
b = str(input('enter random name:'))
c = input(':')
d = float(input('input random:'))
print(b)

a = int(input('fisrt number:'))
b = float(input('secont number:'))
print(a+b)

a = input('input your name:')
print('hello',a)

telehpon_number=int(input("input your phone namber:"))

a=int(input('сколько тебе лет:'))
c=int(input("какой сейчас год?:"))
b=c-a
print('ваш год раждения',b)
print('город в котором он(а) проживает:')


a=int(input('fisrt number: '))
print(a*15)