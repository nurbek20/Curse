# сложения
print(5+6)
print(5-6)
print(5*6)
print(5/6)
print(5//6)
print(5**6)
print(5%6)

# 5>3
# 5<7
# 2==5
# 5!=7
# 5>=7
# 8<=9

print( (17*3)>(12*5) )

print(17925>(34**2))
print(17925>(26*2))
print(17925>(17*33))
print(17925>(4394*4))

print((17*3)>(12*5))
print((12**3)>(13*7))
print((4**5)>(512+512))

hello=2
heelo5=6

sum=hello+heelo5
umn=sum*6
kwad=umn**2
otn=kwad-193432

print(sum)
print(umn)
print(kwad)
print(otn)