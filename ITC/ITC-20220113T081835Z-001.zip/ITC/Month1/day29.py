# words= input("Пишите слова: ").split()
# max_len = len(words[0])
# for i in range(len(words)):
#     if max_len >= len(words[i]):
#         max_len = len(words[i]) 
# lens=sorted(map(len,words))
# dic=[]
# # for i in range(len(words)):     
# #      if len(words.count[i]) < 0:
# #       dic.append=len(words[i])
# # print(len(dic))
# for i in lens:
#     for y in words:
#         if i == len(y):
#             dic.append(y)
#         # if y == 0:
#             break    
            
# print(*dic)
# number = map(int,input("число "))
# print(number)
# """lambda - анонимная функция"""
# def my_fun(num):
#     print(num + 2)
# my_fun(10)

# my_fun2 = lambda num2: num2 + 2
# print(my_fun2(7))

# text = input("введите текст:")
# my_func= lambda text: len(text)
# print(my_func(text))
# print(["Hi"]*4)
# for x in [1,2,3]:
#     print(x)
# tinylist=[1,2,3,'john']
# print(tinylist*2)
# def f(x,l=[]):
#     for i in range(x):
#         l.append(i*i)
#     print(l)
# f(2)
# f(3,[3,2,1])
# f(3)    
# # tuple = ( 'abcd', 786 , 2.23, 'john', 70.2 ) 
# print(tuple[2:])     
# print([1, 2, 3] + [4, 5, 6])
# upper()
# isdecimal()
# swapcase()
# g.title()

for i in range(0,51):
    print(i)
    if i==5:
        print(i,'it')
    elif i==10:
        print(i,'it')
    elif i==15:
        print(i,'it')        
    elif i==20:
        print(i,'it')
    elif i==30:
        print(i,'it')
    elif i==40:
        print(i,'it')
    elif i==50:
        print(i,'it')       
