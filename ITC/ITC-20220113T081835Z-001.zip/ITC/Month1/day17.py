#"""Библиотек, модуль""" 

import day16
day16.find_max([45,5,87,4,54,88])
print(day16.fuzz)

from day16 import fuzz, my_txt, mySum, mult_numbers
print(fuzz)
my_txt("Hello World")
mySum(7,8)
mult_numbers([2,4,65,76,89])


