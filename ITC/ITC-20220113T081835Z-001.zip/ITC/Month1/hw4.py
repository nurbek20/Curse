name=input("как ваше имя:")
age=int(input("ваш год рождения:"))
print(name,"лет",2021-age)

a=int(input("Введите первое число:"))
b=int(input("Введите второе число:"))
c=int(input("Введите третьое число:"))
d=int(input("Введите четвертое число:"))
f=int(input("Введите пьятое число:"))
print(c)

"5+74-53*3.14//6+54"
print(5)

a=int(input("Введите число:"))
b=int(input("Введите второе число:"))
print(a,">",b,"=",a>b)
print(a,"<",b,"=",a<b)
print(a,"==",b,"=",a==b)

a=5
b=7
c=input("Введите знак:")
print(a,c,b)

a=int(input("Введите первое число:"))
b=int(input("Введите второе число:"))
#print(str(a),"+",str(b),"=",str(a+b))
a=str(a)
b=str(b)
print(a+b)